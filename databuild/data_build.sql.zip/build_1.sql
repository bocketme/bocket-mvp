INSERT INTO user (id, username, firstname, lastname, email, password, active, createdat) VALUES
(1, 'admin', 'game', 'throne', 'game@of.throne', 'johnsnow', true, "2004-11-20"),
(2, 'creator', 'sonic', 'mania', 'sonic@mania.fr', 'sonicisthebest', true, "2004-11-20"),
(3, 'nintendo', 'mario', 'odyssey', 'mario@odyssey', 'mariothebest', true, "2004-11-20");

INSERT INTO organization (id, name, id_owner) VALUES
(1, 'The Ultimate', 1);

INSERT INTO team (id, name, id_owner) VALUES
(1, 'THE FIRST ONE', 1);

INSERT INTO ssh_key (id, content) VALUES
(1, 'blablou');

INSERT INTO affectation (id, id_user, id_team, id_ssh_key) VALUES
(1, 1, 1, 1),
(2, 2, 1, 1),
(3, 3, 1, 1);

INSERT INTO files3d (id, name, uuid) VALUES
(1, "project_master", "maja");

INSERT INTO node (id, name, state_of_maturity, is_intermediary, id_project, id_files3d) VALUES
(1, "MASTER", "0", true, 1, 1);

INSERT INTO project (id, name, id_first_node, id_organization, id_team) VALUES
(1, "ZE PROJEKT", 1, 1, 1);

INSERT INTO files3d (id, name, uuid) VALUES
(2,     "tetraedre", "baka"),
(3,     "vide", "caca"),
(4,     "sphere", "soda"),
(5,     "tore", "fafa"),
(6,     "keychain", "moma"),
(7,     "vide", "anas"),
(8,     "vide", "vava"),
(9,     "vide", "joie"),
(10,    "vide", "coca"),
(11,    "vide", "cola");

INSERT INTO node (id, name, state_of_maturity, is_intermediary, node_parent, id_project, id_files3d) VALUES
(2,     "tetraedre", 	"finish", false, 1, 1, 2),
(3,     "vide", 		"vide", true, 1, 1, 3),
(4,     "sphere", 		"finish", false, 3, 1, 4),
(5,     "tore", 		"finish", false, 3, 1, 5),
(6,     "keychain", 	"wait to publish", true, 1, 1, 6),
(7,     "vide", 		"vide", true, 6, 1, 7),
(8,     "vide", 		"vide", true, 6, 1, 8),
(9,     "vide", 		"vide", true, 6, 1, 9),
(10,    "vide", 		"vide", true, 6, 1, 10),
(11,    "vide", 		"vide", true, 6, 1, 11);

INSERT INTO rights (id, administration, id_affectation, id_node) VALUES
-- RIGHTS FOR THE ADMIN
(1, true, 1, 1),
(2, true, 1, 2),
(3, true, 1, 3),
(4, true, 1, 4),
(5, true, 1, 5),
(6, true, 1, 6),
(7, true, 1, 7),
(8, true, 1, 8),
(9, true, 1, 9),
(10, true, 1, 10),
(11, true, 1, 11);

INSERT INTO rights_file (id, read_right, write_right, id_affectation, id_files3d, id_node) VALUES

-- RIGHTS-FILE FOR THE ADMIN
(1, true, true, 1, 1, 1),
(2, true, true, 1, 2, 2),
(3, true, true, 1, 3, 3),
(4, true, true, 1, 4, 4),
(5, true, true, 1, 5, 5),
(6, false, true, 1, 6, 6),
(7, false, true, 1, 7, 7),
(8, false, true, 1, 8, 8),
(9, false, true, 1, 9, 9),
(10, false, true, 1, 10, 10),
(11, false, true, 1, 11, 11),

-- RIGHTS-FILE FOR THE USER-1
(12, false, true, 2, 1,  1),
(13, false, true, 2, 2,  2),
(14, false, true, 2, 3,  3),
(15, false, true, 2, 4,  4),
(16, false, true, 2, 5,  5),
(17, true, false, 2, 6,  6),
(18, true, false, 2, 7,  7),
(19, true, false, 2, 8,  8),
(20, true, false, 2, 9,  9),
(21, true, false, 2, 10, 10),
(22, true, false, 2, 11, 11),

-- RIGHTS-FILE FOR THE USER-2
(23, true, false, 2, 1, 1),
(24, true, false, 2, 2, 2),
(25, true, false, 2, 3, 3),
(26, true, false, 2, 4, 4),
(27, true, false, 2, 5, 5),
(28, false, true, 2, 6, 6),
(29, false, true, 2, 7, 7),
(30, false, true, 2, 8, 8),
(31, false, true, 2, 9, 9),
(32, false, true, 2, 10, 10),
(33, false, true, 2, 11, 11);

INSERT INTO specfiles (id, name, id_node) VALUES
(1, "README.MD", 1);

INSERT INTO rights_file (id, read_right, write_right, id_affectation, id_specfile, id_node) VALUES
(34, true, true, 1, 1, 1),
(35, true, true, 1, 1, 1),
(36, true, true, 1, 1, 1);